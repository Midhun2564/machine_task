import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StoriesComponent } from './components/stories/stories.component';
import { StoryFormComponent } from './components/story-form/story-form.component';
import { AutoSelectedComponent } from './components/auto-selected/auto-selected.component';
import { SprintCalculatorComponent } from './components/sprint-calculator/sprint-calculator.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ErrorPageComponent } from './components/error-page/error-page.component';

@NgModule({
  declarations: [
    AppComponent,
    StoriesComponent,
    StoryFormComponent,
    AutoSelectedComponent,
    SprintCalculatorComponent,
    ErrorPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
