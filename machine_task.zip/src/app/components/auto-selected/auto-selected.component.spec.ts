import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoSelectedComponent } from './auto-selected.component';

describe('AutoSelectedComponent', () => {
  let component: AutoSelectedComponent;
  let fixture: ComponentFixture<AutoSelectedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoSelectedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoSelectedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
