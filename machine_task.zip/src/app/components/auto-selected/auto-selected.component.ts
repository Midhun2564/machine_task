import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/service/common.service';

@Component({
  selector: 'app-auto-selected',
  templateUrl: './auto-selected.component.html',
  styleUrls: ['./auto-selected.component.css']
})
export class AutoSelectedComponent implements OnInit {
  public story : any;
  public isEmpty: boolean = false
  constructor(private commonService:CommonService, private router:Router) { }

  ngOnInit(): void {
    this.commonService.getSelectedStory().subscribe(
      (res) => {
        this.story = res;
      }
    );
    if(this.story.length === 0){
      this.isEmpty = true
    }
  }

  goToCalculate() {
    this.router.navigate(['/calculate'])
  }

  goToAdd() {
    this.router.navigate(['/addStory'])
  }
}
