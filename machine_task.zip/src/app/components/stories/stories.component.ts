import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Story } from 'src/app/Models/Story';
import { CommonService } from 'src/app/service/common.service';

@Component({
  selector: 'app-stories',
  templateUrl: './stories.component.html',
  styleUrls: ['./stories.component.css']
})
export class StoriesComponent implements OnInit {
  public story !:any; 
  public isEmpty:boolean= false;

  constructor(private commonService:CommonService, private router:Router) { }

  ngOnInit(): void {
    this.commonService.getTheStory().subscribe(
      (res)=>{
        this.story = res;
      }
    )
    if(this.story.length === 0){
      this.isEmpty = true;
    }
  }
  goToAdd() {
    this.router.navigate(['/addStory'])
  }

  goToSelect() {
    this.router.navigate(['/calculate'])
  }

}
