import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { CommonService } from 'src/app/service/common.service';

@Component({
  selector: 'app-story-form',
  templateUrl: './story-form.component.html',
  styleUrls: ['./story-form.component.css']
})
export class StoryFormComponent implements OnInit {
  myForm !:FormGroup;
  constructor(private formBuilder: FormBuilder, private commonService:CommonService, private router:Router) { }

  ngOnInit() {
    this.myForm = this.formBuilder.group({
      name: ['', Validators.required],
      points: ['', [Validators.required]]
    });
  }
  
  onSubmit(){
    console.log(this.myForm.value);
    this.router.navigate(['/stories'])
    this.commonService.addToArray(this.myForm.value)
  }
  goToMain() {
    this.router.navigate(['/stories'])
  }
}
