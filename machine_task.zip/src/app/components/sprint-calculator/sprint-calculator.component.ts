import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/service/common.service';

@Component({
  selector: 'app-sprint-calculator',
  templateUrl: './sprint-calculator.component.html',
  styleUrls: ['./sprint-calculator.component.css']
})
export class SprintCalculatorComponent implements OnInit {
  public point !:number;
  public isNumber:boolean = false;

  constructor( private commonService:CommonService, private router:Router) { }

  ngOnInit(): void {
    
  }

  onSubmit(){
    if(typeof(this.point) === "number" && this.point != undefined){
      this.isNumber = true;
      console.log(this.point);
      this.commonService.autoSelect(this.point);
      this.router.navigate(['/autoSelected'])
    } 
    else{
      window.alert("Enter a number")
    }
  }
  onClearSelected(){
    this.commonService.clearSelected();
    this.router.navigate(['/autoSelected'])
  }
  onClear(){
    this.commonService.clearAll();
    this.router.navigate(['/stories'])
  }
}
