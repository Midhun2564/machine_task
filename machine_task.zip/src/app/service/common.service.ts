import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { Story } from '../Models/Story';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  private arr: Story[] = [];
  private auto: Story[] = [];
  public totalSp: number | undefined;

  constructor() {
    this.arr = [
     { name:'Task1', points:1},
     { name:'Task2', points:5},
     { name:'Task3', points:3}
    ]
   }

   addToArray(value: Story): void {
    // Check if the array is empty
    if (this.arr.length === 0) {
      this.arr.push(value); 
    } else {
      this.arr.forEach((item) => {
        // Iterate through each item in the array to check the item is already exist in the array
        if (value.name === item.name) {
          window.alert("Story already exists in the dashboard");
        }
      });
    }
  }

  getTheStory(): Observable<Story[]> {
    return of(this.arr);
  }

  getSelectedStory(){
    return of(this.auto)
  }

  clearAll(): void {
    this.arr = [];
  }

  //selecting the story based on the stoyr points
  autoSelect(maxValue: any): void {
    let sum = 0;
    this.arr.forEach((item: any) => {
      sum = sum + item.points;
      if (sum <= maxValue) {
        this.auto.push(item);
      }
    });
  }

  clearSelected(): void {
    this.auto = [];
  }
}
