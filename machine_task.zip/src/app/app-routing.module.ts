import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StoriesComponent } from './components/stories/stories.component';
import { AutoSelectedComponent } from './components/auto-selected/auto-selected.component';
import { StoryFormComponent } from './components/story-form/story-form.component';
import { SprintCalculatorComponent } from './components/sprint-calculator/sprint-calculator.component';
import { ErrorPageComponent } from './components/error-page/error-page.component';

const routes: Routes = [
  {path:'',pathMatch:'full',redirectTo:'stories'},
  {path:'stories', component:StoriesComponent},
  {path:'autoSelected', component:AutoSelectedComponent},
  {path:'addStory', component:StoryFormComponent},
  {path:'calculate', component:SprintCalculatorComponent},
  {path:'*',component:ErrorPageComponent}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
